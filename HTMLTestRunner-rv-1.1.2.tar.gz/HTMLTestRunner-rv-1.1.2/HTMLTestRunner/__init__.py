from .runner import HTMLTestRunner

__author__ = "Ravikirana B"
__email__ = 'ravikiranb36@gmail.com'
__version__ = '1.1.2'
