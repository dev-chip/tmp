# Surface

Surface provides the bulk of the gRPC Core public API, and translates it into
calls against core components.
